const bodyParser = require('body-parser');
// Importing body parser, so input from forms
// can be parsed
const mysql = require("mysql");
// So that we can connect to the Database
const util = require("util");

//This files includes code adapted from the tutorial video and from the lab sessions by Joe Appleton//

const express = require("express");
const app = express();
const port = 8000;
const ejs = require("ejs");
const { connect } = require('http2');


const DB_HOST = 'localhost';
const DB_USER = 'root';
const DB_NAME = 'coursework';
const DB_PASSWORD = '';
const DB_PORT = 3306;

/**
* Setting up the connection parameters
*/
var connection = mysql.createConnection({
    host: DB_HOST,
    user: DB_USER,
    password: DB_PASSWORD,
    database: DB_NAME,
    port: DB_PORT,
});
/*
* we do this to use async await with mysql
*/
connection.query = util.promisify(connection.query).bind(connection);
/**
* Connecting to the database.
*/
connection.connect(function (err) {
    if (err) {
        console.error("error connecting: " + err.stack);
        return;
    }
    console.log("Booom! We are connected!");
});



app.set("view engine", "ejs");


app.use(express.static("public"));
app.use(bodyParser.urlencoded({ extended: false }));



app.get("/", async (req, res) => {
    /**
    * serves the index.html file from the root of the project. 
    */

    const memberCount = await connection.query('SELECT COUNT(*) as count FROM  ((Register INNER JOIN Student ON Register.URN=Student.URN) INNER JOIN Society ON Register.Soc_ID=Society.Soc_ID)');
    // Counts the number of memebers in a society

    const societyCount = await connection.query('SELECT COUNT(*) as count FROM Society');
    // Counts the number of socities

    const studentCount = await connection.query('SELECT COUNT(*) as count from Student');
    // Counts the number of students

    const studentCount1 = parseInt(studentCount[0].count);
    const memberCount1 = parseInt(memberCount[0].count);
    // Converts the results of counting the students and members
    // into an Integer, so that calculation can be performed,
    // such that the homepage is dynamic

    const result = 0;
    if (!isNaN(memberCount1) && !isNaN(studentCount1)) {
        const result = (memberCount1 / studentCount1) * 100;
    }
    const studentpercent = (memberCount1 / studentCount1) * 100;
    // Calculates the percentage of students in a society
    res.render("index", {
        memberPercent: studentpercent,
        societyCount: societyCount[0].count
    });
});




app.get("/society_members", async (req, res) => {

    const societyMembers = await connection.query('SELECT Student.URN, Student.Stu_FName, Student.Stu_LName, Society.Soc_ID, Society.Soc_Name, Register.Mem_Type FROM  ((Register INNER JOIN Student ON Register.URN=Student.URN) INNER JOIN Society ON Register.Soc_ID=Society.Soc_ID)');

    // Displays all the students in a society, makes use inner joins

    res.render("society_members", { societyMembers: societyMembers });
});



app.get("/viewsocities", async (req, res) => {


    //  Displays all the societies, their categories, and their description.
    // Makes use of Inner Joins

    const socities = await connection.query('SELECT Society.Soc_ID, Society.Soc_Name, Society.Soc_Desc FROM Society');
    res.render("viewsocities", { socities: socities });
});




app.get("/society/view/:id", async (req, res) => {

    // displays the description, categories and members of the specified society

    const categories = await connection.query('SELECT Society.Soc_Name, Society.Soc_ID, Soc_Type.Soc_Catg FROM ((Soc_Type INNER JOIN Society ON Soc_Type.Soc_ID = Society.Soc_ID)) WHERE Society.Soc_ID = ?',
        [req.params.id]);

    const society = await connection.query('SELECT * FROM SOCIETY WHERE Society.Soc_ID = ?',
        [req.params.id]);

    const members = await connection.query('SELECT Student.URN, Student.Stu_FName, Student.Stu_LName, Society.Soc_ID, Society.Soc_Name, Register.Mem_Type FROM  ((Register INNER JOIN Student ON Register.URN=Student.URN) INNER JOIN Society ON Register.Soc_ID=Society.Soc_ID) WHERE Society.Soc_ID = ?',
        [req.params.id]);

    res.render("society_view", { categories: categories, society: society[0], members: members });
})




app.get("/student/view/:id", async (req, res) => {
    const student = await connection.query(
        "SELECT * FROM Student INNER JOIN Course ON student.Stu_Course = course.Crs_Code WHERE URN = ? ",
        [req.params.id]
    );
    // Shows the details specfic to the slected student
    res.render("student_view", { student: student[0] });
});



app.get("/member/view/:id", async (req, res) => {
    const member = await connection.query(
        "SELECT Student.URN, Society.Soc_ID, Student.Stu_FName, Student.Stu_LName, Society.Soc_Name, Register.Mem_Type FROM  ((Register INNER JOIN Student ON Register.URN=Student.URN) INNER JOIN Society ON Register.Soc_ID=Society.Soc_ID) WHERE Register.URN = ?",
        [req.params.id]

    );
    //console.log(member);
    res.render("society_member_view", { member: member, name: member[0] });
});



app.get("/search", async (req, res) => {
    var message = "";

    res.render("search", { message: message });
});



app.get("/students", async (req, res) => {
    /**
    * get all students from the database. Uses an inner join to get the
    course name.
    */
    const students = await connection.query(
        'SELECT * FROM Student INNER JOIN Course ON student.Stu_Course = course.Crs_Code'
    );
    res.render("students", { students: students });
});



app.get("/student/edit/:id", async (req, res) => {
    const student = await connection.query(
        "SELECT * FROM Student WHERE URN = ?",
        [req.params.id]
    );
    const courses = await connection.query("SELECT * FROM Course WHERE Crs_Type = (SELECT Stu_Type FROM Student WHERE URN = ?)", [req.params.id]);
    res.render("student_edit", {
        student: student[0],
        courses: courses,
        message: "",
    });

    // Opens webpage that allows user to edit a
    // specific student's details
});



app.get("/student_add", async (req, res) => {
    const courses = await connection.query('SELECT * FROM Course')
    res.render("student_add", { courses: courses, message: "" });
    // Opens the website that allows the user to add a Student
});



app.get("/student/delete/:id", async (req, res) => {
    const student = await connection.query("SELECT * FROM Student WHERE URN = ?", [req.params.id]
    );
    res.render("student_delete", {
        student: student[0],
        message: "",
    });
    // Opens the webpage that allows the user to delete a student
});


app.get("/search_query", async (req, res) => {

    res.render("/search_results/search_query");
});



app.post("/search", async (req, res) => {
    //console.log(req.body);

    if ((req.body.search_type == "URN" && isNaN(req.body.QUERY)) || (req.body.search_type == "URN" && req.body.QUERY.length != 6) || (req.body.search_type == "URN" && req.body.QUERY > 999999) || (req.body.search_type == "URN" && req.body.QUERY < 100000)) {
        var message = "Invalid URN Query";
        res.render("search", { message: message });

    } else if ((req.body.search_type == "number" && isNaN(req.body.QUERY)) || (req.body.type == "number" && req.body.QUERY.length != 11)) {
        var message = "Invalid Phone Number Query";
        res.render("search", { message: message });

    } else if (req.body.search_type == "Society_ID" && isNaN(req.body.QUERY)) {
        var message = "Invalid Society ID Query";
        res.render("search", { message: message });

    } else {
        if (req.body.search_type == "URN") {
            const result = await connection.query('SELECT * FROM Student INNER JOIN Course ON student.Stu_Course = course.Crs_Code WHERE URN = ?', [req.body.QUERY]);

            const type = "urn";

            res.render("search_query", { results: result, type: type });

        } else if (req.body.search_type == "number") {
            const result = await connection.query('SELECT * FROM Student INNER JOIN Course ON student.Stu_Course = course.Crs_Code WHERE Stu_Phone = ?', [req.body.QUERY]);

            const type = "phone";

            res.render("search_query", { results: result, type: type });

        } else if (req.body.search_type == "Society_Category") {
            const result = await connection.query('SELECT * FROM ((Soc_Type INNER JOIN Society ON Soc_Type.Soc_ID = Society.Soc_ID)) WHERE Soc_Type.Soc_Catg LIKE ?', [req.body.QUERY + '%']);

            const type = "soc_catg";

            res.render("search_query", { results: result, type: type });

        } else if (req.body.search_type == "Society_ID") {
            const result = await connection.query('SELECT * FROM Society WHERE Soc_ID = ?', [req.body.QUERY]);

            const type = "soc_id";

            res.render("search_query", { results: result, type: type });

        } else if (req.body.search_type == "Society_Name") {
            const result = await connection.query('SELECT * FROM Society WHERE Soc_Name LIKE ?', [req.body.QUERY + '%']);

            const type = "soc_name";

            res.render("search_query", { results: result, type: type });

        } else if (req.body.search_type == "FNAME") {
            const result = await connection.query('SELECT * FROM Student INNER JOIN Course ON student.Stu_Course = course.Crs_Code WHERE Stu_FName LIKE ?', [req.body.QUERY + '%']);

            const type = "name";

            res.render("search_query", { results: result, type: type });

        } else if (req.body.search_type == "LNAME") {
            const result = await connection.query('SELECT * FROM Student INNER JOIN Course ON student.Stu_Course = course.Crs_Code WHERE Stu_LName LIKE ?', [req.body.QUERY + '%']);

            const type = "name";

            res.render("search_query", { results: result, type: type });
        }


    }
});


app.post("/student/delete/:id", async (req, res) => {
    var message = "";
    var response = req.body.confirm;

    if (req.body.confirm == "YES") {
        var student_course = await connection.query("SELECT Stu_Course FROM Student WHERE URN = ?", [req.params.id]);
        // Gets the course code of current course student is in
        // console.log(student_course[0].Stu_Course);
        var Stu_Course_Old = student_course[0].Stu_Course;// Get the crs code
        // console.log(Stu_Course_Old);

        var current_enrol = await connection.query("SELECT (Crs_Enrollment) as enrol FROM Course WHERE Crs_Code = ?", [Stu_Course_Old]);
        // console.log(current_enrol[0].enrol);
        // Gets Crs_Enrollment of course student used to be in
        const current_enrolment = current_enrol[0].enrol;
        var current_enrolnum1 = current_enrolment - 1;
        // console.log(current_enrolnum1);

        await connection.query("UPDATE Course SET Crs_Enrollment = ? WHERE Crs_Code = ?", [current_enrolnum1,
            Stu_Course_Old]);
        // //Decrements the student from the number of enrolled students, from their previous course


        await connection.query("DELETE FROM Student WHERE URN = ?",
            [req.params.id]
        );
        message = "Student DELETED";
        // If the input of the form is to confirm the deletion
        // of the student, then the student is deleted, and an appropriate
        // message is shown


    } else if (req.body.confirm == "NO") {
        message = "Student NOT DELETED";
    }
    // If the input of the form is to not delete the student,
    // then the student isn't deleted and an appropriate message is shown

    res.render("student_deleted", {
        message: message,
    });

});


app.post("/student_add", async (req, res) => {
    var message = "";
    var DOB = new Date(req.body.Stu_DOB);

    //calculate month difference from current date in time  
    var month_diff = Date.now() - DOB.getTime();

    //convert the calculated difference in date format  
    var age_date = new Date(month_diff);

    //extract year from date      
    var year = age_date.getUTCFullYear();

    //now calculate the age of the user  
    var age = Math.abs(year - 1970);
    // checks if URN entered is already used
    const dbURN = await connection.query("SELECT URN FROM Student WHERE URN = ?", [req.body.URN]
    );

    // I have calculated the age by extending from this source: https://www.javatpoint.com/calculate-age-using-javascript

    // checks if phone number entered is already used
    const dbPhone = await connection.query("SELECT Stu_Phone FROM Student WHERE Stu_Phone = ?", [req.body.Stu_Phone]
    );

    // listing inputs to form as variables, so that they can be
    // added into the student table
    var URN = req.body.URN;
    var Stu_FName = req.body.Stu_FName;
    var Stu_LName = req.body.Stu_LName;
    var Stu_DOB = req.body.Stu_DOB;
    var Stu_Phone = req.body.Stu_Phone;
    var Stu_Course = req.body.Stu_Course;
    var Stu_Type = req.body.Stu_Type;

    const Crs_Type = await connection.query('SELECT (Crs_Type) as Type FROM Course WHERE Crs_Code = ?',
        [req.body.Stu_Course,
        ]);
    // console.log(req.body.Stu_Type, Crs_Type[0].Type);

    if (isNaN(req.body.Stu_Phone) || req.body.Stu_Phone.length != 11 || dbPhone.length > 0) {
        message = "Please Enter a valid phone number";
        // validation on the phone number

    } else if (18 > age) {
        message = "Please enter a valid date";
        // validation on the age of the student

    } else if (isNaN(req.body.URN) || req.body.URN.length != 6 || dbURN.length > 0 || req.body.URN > 999999 || req.body.URN < 100000) {
        message = "Please Enter a valid URN. It must 6 digits long.";
    } else if (req.body.Stu_Type != Crs_Type[0].Type) {
        message = "Choose valid course";
        // validation on the URN

    } else {
        await connection.query(`INSERT INTO Student VALUES ("${URN}", "${Stu_FName}", "${Stu_LName}", "${Stu_DOB}", "${Stu_Phone}", "${Stu_Course}", "${Stu_Type}")`,
            [req.body,]);

        if (req.body.Crs_Type == "UG") {
            await connection.query(`INSERT INTO Undergraduate VALUES ("${URN}", 120)`, [req.body,]);

        } else if (req.body.Crs_Type == "PG") {
            await connection.query(`INSERT INTO Postgraduate VALUES ("${URN}", "Thesis")`, [req.body,]);
        }

        // If validation is successful, the data is entered into the database

        //await connection.query("INSERT INTO Student VALUE (?)", [
        //	req.body,
        ///]);


        var new_enrol = await connection.query("SELECT (Crs_Enrollment) as enrol FROM Course WHERE Crs_Code = ?", [req.body.Stu_Course]);
        // console.log(new_enrol[0].enrol);
        // Get Crs_Enrollment of course student will now be in

        const new_enrolnum = new_enrol[0].enrol;
        var new_enrolnum1 = new_enrolnum + 1;
        // console.log(new_enrolnum1);

        await connection.query("UPDATE Course SET Crs_Enrollment = ? WHERE Crs_Code = ?", [new_enrolnum1,
            req.body.Stu_Course]);
        //Increments the student to the number of enrolled 



        message = "Student Added";
        //location.redirect(`/students/edit/${dbURN}`);
    }
    const courses = await connection.query('SELECT * FROM Course');
    res.render("student_add", { courses: courses, message: message });
});


app.post("/student/edit/:id", async (req, res) => {
    var message = "";
    var student_course = await connection.query("SELECT Stu_Course FROM Student WHERE URN = ?", [req.params.id]);
    // Gets the course code of current course student is in
    // console.log(student_course[0].Stu_Course);
    var Stu_Course_Old = student_course[0].Stu_Course;// Get the crs code
    // console.log(Stu_Course_Old);


    if (isNaN(req.body.Stu_Phone) || req.body.Stu_Phone.length != 11) {
        message = "Please enter a valid phone number!";
        // validation on the phone number
    } else {
        await connection.query("UPDATE Student SET ? WHERE URN = ?", [
            req.body,
            req.params.id,
        ]);
        if (student_course != req.body.Stu_Course) {


            var current_enrol = await connection.query("SELECT (Crs_Enrollment) as enrol FROM Course WHERE Crs_Code = ?", [Stu_Course_Old]);
            // console.log(current_enrol[0].enrol);
            // Gets Crs_Enrollment of course student used to be in

            const current_enrolment = current_enrol[0].enrol;
            var current_enrolnum1 = current_enrolment - 1;
            // console.log(current_enrolnum1);

            var new_enrol = await connection.query("SELECT (Crs_Enrollment) as enrol FROM Course WHERE Crs_Code = ?", [req.body.Stu_Course]);
            // console.log(new_enrol[0].enrol);
            // Get Crs_Enrollment of course student will now be in

            const new_enrolnum = new_enrol[0].enrol;
            var new_enrolnum1 = new_enrolnum + 1;
            // console.log(new_enrolnum1);

            await connection.query("UPDATE Course SET Crs_Enrollment = ? WHERE Crs_Code = ?", [current_enrolnum1,
                Stu_Course_Old]);
            // //Decrements the student from the number of enrolled students, from their previous course

            await connection.query("UPDATE Course SET Crs_Enrollment = ? WHERE Crs_Code = ?", [new_enrolnum1,
                req.body.Stu_Course]);
            //Increments the student to the number of enrolled 

        }

        message = "Student record updated";
    }
    const student = await connection.query(
        "SELECT * FROM Student WHERE URN = ?",
        [req.params.id]
    );
    const courses = await connection.query("SELECT * FROM Course WHERE Crs_Type = (SELECT Stu_Type FROM Student WHERE URN = ?)", [req.params.id]);
    res.render("student_edit", {
        student: student[0],
        courses: courses,
        message: message,
    });
});


app.listen(port, () => {
    console.log(`The website is listening at http://localhost:${port}`);
});